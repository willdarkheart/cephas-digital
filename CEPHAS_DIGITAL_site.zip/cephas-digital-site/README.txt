CEPHAS DIGITAL — site vitrine

Fichier principal : index.html
Site responsive (mobile et ordinateur), en français, sans dépendances externes.

Pour publier gratuitement depuis Android :
1. Crée un compte GitHub et un nouveau dépôt public nommé cephas-digital.
2. Téléverse index.html à la racine du dépôt.
3. Crée un compte Netlify, puis choisis l'import depuis GitHub et sélectionne ce dépôt.
4. Publie le site. Netlify donnera une adresse publique gratuite en .netlify.app.
5. Tu pourras ensuite relier un nom de domaine personnalisé si tu en achètes un.

Avant publication : vérifie le numéro WhatsApp et remplace les maquettes d'exemple par tes vrais travaux quand tu en auras. Les maquettes sont explicitement présentées comme des concepts, pas comme des commandes clients.
